import { Given, When, Then } from '@wdio/cucumber-framework';
import { expect, $ } from '@wdio/globals'
import articlePage from '../page-objects/article.page.js';


Given(/^the user is on the (\w+) page$/, async (page) => {
    await articlePage.open(page);
});

When(/^the user clicks on Get a day pass, yellow button, inside the article$/, async () => {
        await articlePage.validateDayPass();
 });

Then(/^the user fills in a random email address$/, async () => {
        await articlePage.validateEmail();
});

Then(/^the user selects (.*) as the country and enters a valid UK postcode$/, async (country) => {
        await articlePage.validateCountryPostcode(country);
});

Then(/^the user selects a random preference for marketing preferences$/, async () => {
        await articlePage.validatePreferences();
});

Then(/^the user clicks continue$/, async () => {
        await articlePage.validateContinueButton();
});

Then(/^the user selects any payment amount$/, async () => {
    await articlePage.validateAmount(); 
});

Then(/^the user selects Voucher$/, async () => {
    await articlePage.selectVoucher();
});

Then(/^the user fills in (.*) number and the user should see confirmation message$/, async (voucher) => {
    await articlePage.validateVoucherDetails(voucher);
// });

// Then(/^the user clicks continue$/, async () => {
    await articlePage.validateRedeemVoucher();
// });

// // Then(/^ the user should see confirmation <message>$/, async () => {
    await articlePage.validateConfirmationPayment();
// // });
});