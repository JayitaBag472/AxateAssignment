import { $ } from '@wdio/globals'
import Page from './page.page.js';
/**
 * sub page containing specific selectors and methods for a specific page
 */
class ArticlePage extends Page {

      get dayPassButton() {return $('//a[@class="submit-button"]');}
      get iframepath() {return $('//iframe[@id="axate-notice"]');}
      get continueButton() {return $('//button[contains(text(),"Continue")]')}
      get emailID() {return $('//input[@id="email"]');}
      get country() {return $('//select[@id="country"]');}
      get postcode() {return $('//input[@id="postcode"]');}
      get img() {return $('//img[@class="publisherLogo image--loaded"]');}
      get marketingNewRadioBtn() {return $('//input[@name="publisher_marketing_news" and @value="false"]');}
      get marketingOffersRadioBtn() {return $('//input[@name="publisher_marketing_offers" and @value="false"]');}
      get axateMarketingRadioBtn() {return $('//input[@name="axate_marketing" and @value="false"]');}
      get continueButton1() {return $('//button[@class="global-submitButton sign-up__button"]');}
      get continueButton2() {return $('//button[@class="global-submitButton sign-up__button"]');}
      get vocherButton() {return $('(//span[contains(text(),"Voucher")])[1]');}
      get vocherText() {return $('//input[@id="voucher"]');}
      get redeemButton() {return $('//input[@value="Redeem"]');}
      get confirmMessage() {return $('//h4[contains(text(),"You are ready to read your first article.")]');}

     

    open(page) {
        return super.open(page);
    }

    async validateDayPass()
    {
    
        await expect(this.iframepath).toBeDisplayed();
        await this.iframepath.click();  
        const iframe = await $("//iframe[@id='axate-notice']");
        await browser.switchToFrame(iframe);
        await this.dayPassButton.click();  
        await browser.url("https://accounts-staging.axate.io/get-started?pub_id=YRKS&publication_name=The%20Yorkshire%20Post%20Staging&url_from=https%3A%2F%2Fyrk.branch-master.axate.io%2Farticles%2F1&variant=3&notice_subtype=null&signup_source=first-use&pricing_variant=0")
        await this.continueButton.click(); 
    }

    async validateEmail(){
        await browser.url("https://accounts-staging.axate.io/register?publication_name=The%20Yorkshire%20Post%20Staging&pub_id=YRKS&url_from=https%3A%2F%2Fyrk.branch-master.axate.io%2Farticles%2F1&pricing_variant=0&isIframe=false&voucher_code=&voucher=&link_for_passwordless=&amount=0&selected_amount=0&country=&currency=&sales_tax_rate=&subscription_plan=&plan_id=&first_transaction=&fromBanner=false&fromLogin=&variant=3&email=&isResend=false&resendTo=%2Fregister&isContribution=false&token=&subscription_status=&skip_payment=false&payment_type=&publication_has_subscription=false&axate_subscription_expiry_date=&axate_subscription_id=&from=&subscription_months=&subscription_cost=0&signup_source=first-use&redirect_after=&testing=false&type=&back=&extra_route=&debug=&cookieFound=&notice_subtype=null&promo=&conversion=") 
        await expect(this.emailID).toBeDisplayed();
        function getRandomEmail(domain,length)
        {
            var text = "";
            var possible = "ABCDEFGHIJKLMNOPQRSTUVWXYZabcdefghijklmnopqrstuvwxyz0123456789";
            for( var i=0; i < length; i++ )
                text += possible.charAt(Math.floor(Math.random() * possible.length));
            return text + domain;
        }
        var email = getRandomEmail("@domain.com",15);
        await this.emailID.setValue(email); 
    }

        async validateCountryPostcode(country){
        await expect(this.country).toBeDisplayed();
        await expect(this.postcode).toBeDisplayed(); 
       const value = await $("#country")
       await value.selectByVisibleText(country)
        await this.postcode.setValue('CR0 4FP');
        browser.pause(2000);  
        }

        async validatePreferences(){
        await this.marketingNewRadioBtn.click();
        browser.pause(2000);  
        await this.marketingOffersRadioBtn.click();
        browser.pause(2000);  
        await this.axateMarketingRadioBtn.click();
        browser.pause(2000);  
        }

        async validateContinueButton(){
        await this.continueButton1.click();  
        await browser.pause(2000);  
    }

        async validateAmount(){
        await this.continueButton2.click();  
        }
        async selectVoucher(){
        await browser.pause(5000);  
        browser.url("https://accounts-staging.axate.io/payment?publication_name=The%20Yorkshire%20Post%20Staging&pub_id=YRKS&url_from=https%3A%2F%2Fyrk.branch-master.axate.io%2Farticles%2F1&pricing_variant=0&isIframe=false&voucher_code=&voucher=&link_for_passwordless=&amount=1&selected_amount=0&country=&currency=GBP&sales_tax_rate=0&subscription_plan=&plan_id=&first_transaction=&fromBanner=false&fromLogin=&variant=3&email=&isResend=false&resendTo=%2Fregister&isContribution=false&token=&subscription_status=&skip_payment=false&payment_type=&publication_has_subscription=false&axate_subscription_expiry_date=&axate_subscription_id=&from=&subscription_months=&subscription_cost=0&signup_source=first-use&redirect_after=&testing=false&type=&back=&extra_route=&debug=&cookieFound=&notice_subtype=null&promo=&conversion=new_user")
        await browser.refresh();
        await browser.pause(5000);  
        await this.vocherButton.click();  
        await browser.pause(1000);
        }

        async validateVoucherDetails(voucher){
        await this.vocherText.setValue(voucher);
        await browser.pause(1000);}

        async validateRedeemVoucher(){
        await this.redeemButton.click();  
        await browser.pause(5000);}

        async validateConfirmationPayment(){
        const iframe1 = await $("//iframe[@id='iframe__popup_notices']");
        await browser.switchToFrame(iframe1);
        await expect(this.confirmMessage).toBeDisplayed();
        }    

    
}

export default new ArticlePage();
