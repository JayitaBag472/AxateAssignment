import fs from 'node:fs/promises'
import { browser } from '@wdio/globals'
import { generate } from 'multiple-cucumber-html-reporter'
import cucumberJson from 'wdio-cucumberjs-json-reporter';
import { join } from 'path'
import path from 'path'


global.downloadDir = path.join(__dirname, 'features/file-download');

export const config = {
    runner: 'local',
    specs: [
        './features/**/feature-files/**/*.feature'
    ],
    // Patterns to exclude.
    exclude: [
        // 'path/to/excluded/files'
    ],
    // ============
    // Capabilities
    // ============
    maxInstances: 10,
    capabilities: [
        {
            browserName: 'firefox',
            'moz:firefoxOptions': {
                // Add Firefox options here
                args: ['disable-gpu'], // Example: Launch Firefox in headless mode,
                prefs: {
                    'directory_upgrade': true,
                    'prompt_for_download': false,
                    'download.default_directory': global.downloadDir
                }
            }
        }
    ],
    // Define all options that are relevant for the WebdriverIO instance here
    //
    // Level of logging verbosity: trace | debug | info | warn | error | silent
    logLevel: 'error',
    // If you only want to run your tests until a specific amount of tests have failed use
    // bail (default is 0 - don't bail, run all tests).
    bail: 0,
    // Set a base URL in order to shorten url command calls. If your `url` parameter starts
    // with `/`, the base url gets prepended, not including the path portion of your baseUrl.
    // If your `url` parameter starts without a scheme or `/` (like `some/path`), the base url
    // gets prepended directly.
    baseUrl: 'http://localhost',
    //
    // Default timeout for all waitFor* commands.
    waitforTimeout: 10000,
    //
    // Default timeout in milliseconds for request
    // if browser driver or grid doesn't send response
    connectionRetryTimeout: 120000,
    //
    // Default request retries count
    connectionRetryCount: 3,
    //
    // Test runner services
    // Services take over a specific job you don't want to take care of. They enhance
    // your test setup with almost no effort. Unlike plugins, they don't add new
    // commands. Instead, they hook themselves up into the test process.
    services: [
    ],
    //
    // Framework you want to run your specs with.
    // The following are supported: Mocha, Jasmine, and Cucumber
    // see also: https://webdriver.io/docs/frameworks
    framework: 'cucumber',
    // Test reporter for stdout.
    // The only one supported by default is 'dot'
    // see also: https://webdriver.io/docs/dot-reporter
    reporters: ['spec',
        ['cucumberjs-json', {
            jsonFolder: 'reports/bdd-results/json/',
            language: 'en',
        },
        ]
    ],

    // If you are using Cucumber you need to specify the location of your step definitions.
    cucumberOpts: {
        // <string[]> (file/dir) require files before executing features
        require: ['./features/step-definitions/*.js'],
        // <boolean> show full backtrace for errors
        backtrace: false,
        // <string[]> ("extension:module") require files with the given EXTENSION after requiring MODULE (repeatable)
        requireModule: [],
        // <boolean> invoke formatters without executing steps
        dryRun: false,
        // <boolean> abort the run on first failure
        failFast: false,
        // <boolean> hide step definition snippets for pending steps
        snippets: true,
        // <boolean> hide source uris
        source: true,
        // <boolean> fail if there are any undefined or pending steps
        strict: false,
        // <string> (expression) only execute the features or scenarios with tags matching the expression
        tagExpression: '',
        // <number> timeout for step definitions
        timeout: 60000,
        // <boolean> Enable this config to treat undefined definitions as warnings.
        ignoreUndefinedDefinitions: false
    },
    // =====
    // Hooks
    // =====
    /**
     * Gets executed once before all workers get launched.
     * @param {object} config wdio configuration object
     * @param {Array.<Object>} capabilities list of capabilities details
     */
    onPrepare: function () {
        // Create Directories for Fit Attributes Matching results
        fs.mkdir('features/attr-matching-results/Web',{ recursive: true })
        fs.mkdir('features/attr-matching-results/Api',{ recursive: true })
        fs.mkdir(global.downloadDir, { recursive: true })
        fs.rm(global.downloadDir, { recursive: true })

        fs.mkdir('reports/bdd-results/', { recursive: true })

        return fs.rm('reports/bdd-results/', { recursive: true });
    },
    /**
     *
     * Runs after a Cucumber Step.
     * @param {Pickle.IPickleStep} step             step data
     * @param {IPickle}            scenario         scenario pickle
     * @param {object}             result           results object containing scenario results
     * @param {boolean}            result.passed    true if scenario has passed
     * @param {string}             result.error     error stack if scenario failed
     * @param {number}             result.duration  duration of scenario in milliseconds
     * @param {object}             context          Cucumber World object
     */
    afterStep: async function (step, scenario, result, error, context) {
        if (result.passed == false) {
            cucumberJson.attach(await browser.takeScreenshot(), 'image/png');
        }
    },
    /**
     * Gets executed after all workers got shut down and the process is about to exit. An error
     * thrown in the onComplete hook will result in the test run failing.
     * @param {object} exitCode 0 - success, 1 - fail
     * @param {object} config wdio configuration object
     * @param {Array.<Object>} capabilities list of capabilities details
     * @param {<Object>} results object containing test results
     */
    onComplete: function () {
        // Generate the report when it all tests are done
        generate({
            jsonDir: 'reports/bdd-results/json/',
            reportPath: 'reports/bdd-results/html-reports/',
            openReportInBrowser: false,
            reportName: 'Gen AI TSO POC Execution Report',
            displayDuration: true,
            durationInMS: false,
            displayReportTime: true,
            hideMetadata: false,
        });
    },
}
